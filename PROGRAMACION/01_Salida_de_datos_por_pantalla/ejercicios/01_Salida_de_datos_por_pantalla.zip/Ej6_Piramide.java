/**
 * Explica tu código aquí
 * 
 * @author Miguel Ávila
 */
public class Ej6_Piramide {
  public static void main(String[] args) {
    System.out.println("    * ");
    System.out.println("   ***");
    System.out.println("  *****");
    System.out.println(" *******");
    System.out.println("*********");
  }
    
}