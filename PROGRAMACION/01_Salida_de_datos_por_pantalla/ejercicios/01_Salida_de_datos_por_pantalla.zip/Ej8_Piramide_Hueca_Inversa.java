/**
 * Explica tu código aquí
 * 
 * @author Miguel Ávila
 */
public class Ej8_Piramide_Hueca_Inversa {
  public static void main(String[] args) {
    System.out.println("*********");
    System.out.println(" *     *");
    System.out.println("  *   *");
    System.out.println("   * *");
    System.out.println("    *");
  }
    
}