public class Ejercicio3 {
  public static void main(String[] args) {
    
    String nombre = "Miguel Ángel Ávila Rosas";
    String telefono = "621-38-50-41";
    String direccion = "Calle Ebro nº16";

    System.out.println("Nombre: " + nombre);
    System.out.println("Telefono: " + telefono);
    System.out.println("Dirección: " + direccion);
  }
}