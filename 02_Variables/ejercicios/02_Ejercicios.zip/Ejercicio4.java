public class Ejercicio4 {
  public static void main(String[] args) {
    float euros;
    float pesetas;

    euros = 6;
    pesetas = 166 * euros;

    System.out.printf("%.2f € son %.0f pesetas", euros,pesetas);
  }
}