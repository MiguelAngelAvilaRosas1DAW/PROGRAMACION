public class Ejercicio2 {
  public static void main(String[] args) {
    
    String nombre = "Miguel Ángel Ávila Rosas";
    System.out.println(nombre);
  }
}
