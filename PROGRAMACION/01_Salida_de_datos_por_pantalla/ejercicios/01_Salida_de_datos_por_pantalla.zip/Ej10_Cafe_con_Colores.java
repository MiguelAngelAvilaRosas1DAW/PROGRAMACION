/**
 * Explica tu código aquí
 * 
 * @author Miguel Ávila
 */
public class Ej10_Cafe_con_Colores{
  public static void main (String[] args) {
    System.out.println("\033[44m");
    System.out.println("\033[44m");
    System.out.println("\033[44m");
    System.out.println("\033[44m");
    System.out.println("                                                  \033[36mAPRENDE JAVA\033[44m                                    \033[47m  \033[44m            \033[47m  \033[44m");
    System.out.println("                                                 \033[36mCON EJERCICIOS\033[44m                                     \033[47m  \033[44m            \033[47m  \033[44m");
    System.out.println("                                                                                                  \033[47m  \033[44m            \033[47m  \033[44m");
    System.out.println("\033[44m");
    System.out.println("                                                                                            \033[41m                           \033[44m");
    System.out.println("                                                                                            \033[41m                                   \033[44m");
    System.out.println("                                            \033[36mMIGUEL ÁNGEL ÁVILA ROSAS\033[44m                        \033[41m                           \033[44m      \033[41m  \033[44m");
    System.out.println("                                                                                            \033[41m                           \033[44m      \033[41m  \033[44m");
    System.out.println("                                                                                            \033[41m                                   \033[44m");
    System.out.println("                                                                                            \033[41m                           \033[105m");
    System.out.println("\033[105m");
    System.out.println("\033[105m");
    System.out.println("\033[105m\033[0m");
  }
}
