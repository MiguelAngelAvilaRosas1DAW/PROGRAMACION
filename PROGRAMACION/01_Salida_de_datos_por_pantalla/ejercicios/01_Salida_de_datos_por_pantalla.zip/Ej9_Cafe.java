/**
 * Explica tu código aquí
 * 
 * @author Miguel Ávila
 */
public class Ej9_Cafe {
  public static void main (String[] args) {
    System.out.println("\033[40m");
    System.out.println("\033[40m");
    System.out.println("\033[40m");
    System.out.println("\033[40m");
    System.out.println("                                                  APRENDE JAVA                                    \033[47m  \033[40m            \033[47m  \033[40m");
    System.out.println("                                                 CON EJERCICIOS                                     \033[47m  \033[40m            \033[47m  \033[40m");
    System.out.println("                                                                                                  \033[47m  \033[40m            \033[47m  \033[40m");
    System.out.println("\033[40m");
    System.out.println("                                                                                            \033[47m                           \033[40m");
    System.out.println("                                                                                            \033[47m                                   \033[40m");
    System.out.println("                                            MIGUEL ÁNGEL ÁVILA ROSAS                        \033[47m                           \033[40m      \033[47m  \033[40m");
    System.out.println("                                                                                            \033[47m                           \033[40m      \033[47m  \033[40m");
    System.out.println("                                                                                            \033[47m                                   \033[40m");
    System.out.println("                                                                                            \033[47m                           \033[100m");
    System.out.println("\033[100m");
    System.out.println("\033[100m");
    System.out.println("\033[100m\033[0m");
  }
}
