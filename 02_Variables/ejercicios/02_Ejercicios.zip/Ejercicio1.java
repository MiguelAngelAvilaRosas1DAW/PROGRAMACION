public class Ejercicio1 {
  public static void main(String[] args) {
   
    int x ;
    int y ;
    int suma ;
    int resta ;
    int multiplicacion ;
    float division ;

    x = 144 ; 
    y = 999 ;
    suma = x + y ;
    resta = x - y ;
    multiplicacion = x * y ;
    division = x / y ;

    System.out.println("x = " + x) ;
    System.out.println("y = " + y) ;
    System.out.println("x + y = " + suma) ;
    System.out.println("x - y = " + resta) ;
    System.out.println("x / y = " + division) ;
    System.out.println("x * y = " + multiplicacion) ;
  }
}
