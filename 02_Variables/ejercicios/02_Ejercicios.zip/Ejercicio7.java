public class Ejercicio7 {
  public static void main (String[] args){
    char a;
    char z;
    String abecedario;

    a = 'a';
    z = 'z';
    abecedario = "abecedario";

    System.out.println(a + z + abecedario);

    //Aparentemente la a y la z no se muestran, por el contrario aparecen números.
  }
}
