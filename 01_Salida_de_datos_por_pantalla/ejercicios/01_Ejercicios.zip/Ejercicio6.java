/**
 * Explica tu código aquí
 * 
 * @author Miguel Ávila
 */
public class Ejercicio6 {
  public static void main(String[] args) {
    //Variables:

    System.out.printf("%5c\n", '*');
    System.out.printf("%6s\n", "***");
    System.out.printf("%7s\n", "*****");
    System.out.printf("%8s\n", "*******");
    System.out.printf("%9s\n", "*********");
  }
    
}