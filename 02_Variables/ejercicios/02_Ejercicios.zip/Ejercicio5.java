public class Ejercicio5 {
  public static void main(String[] args) {
    float euros;
    int pesetas;

    pesetas = 10000;
    euros = pesetas / 166;

    System.out.printf("%d pesetas son %.2f", pesetas,euros);
  }
}
