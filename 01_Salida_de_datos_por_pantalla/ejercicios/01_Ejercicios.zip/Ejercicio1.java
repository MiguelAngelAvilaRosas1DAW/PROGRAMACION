/**
 * Con este codigo mostrare mi nombre por pantalla.
 * 
 * @author Miguel Ávila
 */
public class Ejercicio1 {
  public static void main(String[] args) {
    System.out.println("Miguel Ángel Ávila Rosas");
  }
}
