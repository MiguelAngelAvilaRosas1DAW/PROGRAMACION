/**
 * Este programa mostrara por pantalla mi nombre, numero de teléfono y dirección.
 * 
 * @author Miguel Ávila
 */
public class Ejercicio2 {
  public static void main (String [] args) {
    System.out.println("Nombre: Miguel Ángel Ávila Rosas");
    System.out.println("Numero de teléfono: 621-38-50-41");
    System.out.println("Dirección: Calle Ebro, nº 16");
  }
}
